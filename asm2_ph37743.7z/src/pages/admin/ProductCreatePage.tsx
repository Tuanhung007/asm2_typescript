import ProductAddForm from '@/components/ProductAddForm'

const ProductCreatePage = () => {
  return (
    <div>
      <ProductAddForm />
    </div>
  )
}

export default ProductCreatePage
